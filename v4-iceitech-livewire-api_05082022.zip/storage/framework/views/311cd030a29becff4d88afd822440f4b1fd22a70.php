 <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
        ICEITech Laravel 9 - CRUD Productos Livewire con JetStream
    </h2>
 <?php $__env->endSlot(); ?>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if(session()->has('message')): ?>
                <div class="bg-<?php echo e(session('type')); ?>-100 border-t-4 border-<?php echo e(session('type')); ?>-500 rounded-b text-<?php echo e(session('type')); ?>-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>
            <button wire:click="create()" class="bg-green-500 hover:bg-green-700 text-white py-1 mb-6 px-3 rounded my-3 mt-1">Crear Nuevo Producto</button>
            <?php if($isOpen): ?>
                <?php echo $__env->make('livewire.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <table class="table-fixed w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 w-20">Nro.</th>
                        <th class="px-4 py-2">Nombre</th>
                        <th class="px-4 py-2">Detalle</th>
                        <th class="px-4 py-2 w-60">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($product['id']); ?></td>
                        <td class="border px-4 py-2"><?php echo e($product['name']); ?></td>
                        <td class="border px-4 py-2"><?php echo e($product['detail']); ?></td>
                        <td class="border px-4 py-2 text-center">
                        <button wire:click="edit(<?php echo e($product['id']); ?>)" class="bg-blue-500 hover:bg-blue-700 text-white py-1 px-3 rounded">Editar</button>
                            <button wire:click="delete(<?php echo e($product['id']); ?>)" class="bg-red-500 hover:bg-red-700 text-white py-1 px-3 rounded">Eliminar</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH E:\www\v4\v4-iceitech-livewire-api\resources\views/livewire/products.blade.php ENDPATH**/ ?>